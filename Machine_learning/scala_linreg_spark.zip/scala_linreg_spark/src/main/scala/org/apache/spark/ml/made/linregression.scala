package org.apache.spark.ml.made

import breeze.linalg.{sum, DenseVector => BDV}
import org.apache.spark.SparkContext
import org.apache.spark.ml.feature.VectorAssembler
import org.apache.spark.ml.linalg.{DenseVector, Vector, VectorUDT, Vectors}
import org.apache.spark.ml.param.{DoubleParam, IntParam, ParamMap}
import org.apache.spark.ml.param.shared.{HasInputCol, HasOutputCol}
import org.apache.spark.ml.util.{DefaultParamsReadable, DefaultParamsWritable, Identifiable, SchemaUtils}
import org.apache.spark.ml.{Estimator, Model}
import org.apache.spark.sql.{DataFrame, Dataset, functions}
import org.apache.spark.sql.types.{NumericType, StructType}
import breeze.linalg.norm
import org.apache.spark.internal.Logging
import org.apache.spark.ml.linalg.{Vector, Vectors}
import org.apache.spark.sql.catalyst.encoders.ExpressionEncoder
import org.apache.spark.sql.{Dataset, Encoder, Row}
import org.apache.spark.sql.expressions.Aggregator
import breeze.linalg.{Vector => BV, axpy => brzAxpy}



abstract class Updater private[made] extends Serializable {
  def compute(
               weightsOld: Vector,
               gradient: Vector,
               stepSize: Double,
               iter: Int): Vector
}

class BasicUpdater private[made] extends Updater {
  override def compute(weightsOld: Vector,
                       gradient: Vector,
                       stepSize: Double,
                       iter: Int): Vector = {
    val brzWeights: BV[Double] = weightsOld.asBreeze.toDenseVector
    // use specialized axpy for better performance
    brzAxpy(-stepSize, gradient.asBreeze, brzWeights)

    Vectors.fromBreeze(brzWeights)
  }
}

class GradientDescent private[made] (private var gradient: Gradient,
                                     private var updater: Updater,
                                     private var inputCol: String,
                                     private var outputCol: String)
  extends Serializable with Logging {

  private var stepSize: Double = 1.0
  private var numIterations: Int = 100

  def setStepSize(step: Double): this.type = {
    this.stepSize = step
    this
  }

  def setNumIterations(iters: Int): this.type = {
    this.numIterations = iters
    this
  }

  def setInputCol(inputCol: String): this.type = {
    this.inputCol = inputCol
    this
  }

  def setOutputCol(outputCol: String): this.type = {
    this.outputCol= outputCol
    this
  }

  def check_norm(currWeights: Vector,
                 nextWeights: Vector): Boolean = {
    val _norm_val: Double = norm(currWeights.asBreeze.toDenseVector - nextWeights.asBreeze.toDenseVector)
    _norm_val < 0.001 * Math.max(norm(nextWeights.asBreeze.toDenseVector), 1.0)
  }

  def evaluate(dataset: Dataset[_], initialWeights: Vector): (Vector) = {

    var bestLoss = Double.MaxValue

    var currWeights: Option[Vector] = None
    var nextWeights: Option[Vector] = None

    var weights = Vectors.dense(initialWeights.toArray)
    var bestWeights = weights
    val weights_count = weights.size
    val rows_count = dataset.count()

    var converged = false // indicates whether converged based on convergenceTol
    var i = 1
    while (!converged && i <= numIterations) { //!converged &&

      val customSummer =  new Aggregator[Row, (Vector, Double), (Vector, Double)] {
        def zero: (Vector, Double) = (Vectors.zeros(weights_count), 0.0)
        def reduce(acc: (Vector, Double), x: Row): (Vector, Double) = {
          val (grad, loss) = gradient.compute(x.getAs[Vector](inputCol), x.getAs[Double](outputCol), weights)
          (Vectors.fromBreeze(acc._1.asBreeze + grad.asBreeze / rows_count.asInstanceOf[Double]),
            acc._2 + loss / rows_count.asInstanceOf[Double])
        }
        def merge(acc1: (Vector, Double), acc2: (Vector, Double)): (Vector, Double) = (Vectors.fromBreeze(acc1._1.asBreeze + acc2._1.asBreeze), acc1._2 + acc2._2)
        def finish(r: (Vector, Double)): (Vector, Double) = r
        override def bufferEncoder: Encoder[(Vector, Double)] = ExpressionEncoder()
        override def outputEncoder: Encoder[(Vector, Double)] = ExpressionEncoder()
      }.toColumn

      val row = dataset.select(customSummer.as[(Vector, Double)](ExpressionEncoder()))

      val loss = row.first()._2
      weights = updater.compute(weights, row.first()._1, stepSize, i)


      currWeights = nextWeights
      nextWeights = Some(weights)

      if (currWeights.isDefined && nextWeights.isDefined) {
        converged = check_norm(currWeights.get, nextWeights.get)
      }

      if (loss < bestLoss) {
        bestLoss = row.first()._2
        bestWeights = weights
      }

      println(s"Iter = ${i}, numIterations = ${numIterations}")
      i += 1
    }


    weights
  }


}

class Gradient extends Serializable {
  // Compute the gradient and loss
  def compute(data: Vector, label: Double, weights: Vector): (Vector, Double) = {
    val _delta = sum(data.asBreeze *:* weights.asBreeze) - label // h_theta(x) - y_i
    val _loss = _delta * _delta / 2.0                               // diff^2 / 2
    val _grad = data.copy.asBreeze * _delta                   // \d / \dTheta J_Theta = x * _delta
    (Vectors.fromBreeze(_grad), _loss)
  }
}

trait HasInOutColumns extends HasInputCol with HasOutputCol {
  def setInputCol(value: String) : this.type = set(inputCol, value)
  def setOutputCol(value: String): this.type = set(outputCol, value)

  setDefault(inputCol, "features")
  setDefault(outputCol, "label")
}


trait LinearRegressionParams extends HasInOutColumns {
  protected def validateAndTransformSchema(schema: StructType): StructType = {
    SchemaUtils.checkColumnType(schema, getInputCol, new VectorUDT())

    if (schema.fieldNames.contains($(outputCol))) {
      SchemaUtils.checkNumericType(schema, getOutputCol)
      schema
    } else {
      SchemaUtils.appendColumn(schema, schema(getInputCol).copy(name = getOutputCol))
    }
  }
}

class LinearRegression(override val uid: String) extends Estimator[LinearRegressionModel] with LinearRegressionParams
with DefaultParamsWritable {

  final val stepSize = new DoubleParam(this, "stepSize", "step")
  final val numIterations = new IntParam(this, "numIterations", "iter")
  def this() = this(Identifiable.randomUID("linearRegression"))

  def getStepSize = $(stepSize)
  def getNumIterations = $(numIterations)

  def setStepSize(step: Double) = set(stepSize, step)
  def setNumIterations(num: Int) = set(numIterations, num)

  private val gradient = new Gradient()
  private val updater = new BasicUpdater()
  private lazy val gradWeights = new GradientDescent(gradient, updater, $(inputCol), $(outputCol))
    .setStepSize(getStepSize)
    .setNumIterations(getNumIterations)

  override def setInputCol(value: String) : this.type = {
    set(inputCol, value)
    gradWeights.setInputCol($(inputCol))
    this
  }

  override def setOutputCol(value: String): this.type = {
    set(outputCol, value)
    gradWeights.setOutputCol($(outputCol))
    this
  }

  override def fit(dataset: Dataset[_]): LinearRegressionModel = {
    val weightInit: Vector = Vectors.dense(1.0, 1.0, 1.0, 1.0)

    val withOnes = dataset.withColumn("ones", functions.lit(1))
    val assembler = new VectorAssembler()
      .setInputCols(Array($(inputCol), "ones"))
      .setOutputCol("features_extended")

    val assembled = assembler
      .transform(withOnes)
      .select(functions.col("features_extended").as($(inputCol)), functions.col($(outputCol)))

    val weights = gradWeights.evaluate(assembled, weightInit)

    copyValues(new LinearRegressionModel(new DenseVector(weights.toArray.slice(0, 3)), weights.toArray(3))).setParent(this)
  }

  override def copy(extra: ParamMap): Estimator[LinearRegressionModel] = ???

  override def transformSchema(schema: StructType): StructType = validateAndTransformSchema(schema)
}

object LinearRegression extends DefaultParamsReadable[LinearRegression]{
  def apply(s: String) = new LinearRegression(s)
}

class LinearRegressionModel private[made](
                           override val uid: String,
                           val weights: DenseVector,
                           val w0: Double) extends Model[LinearRegressionModel] with LinearRegressionParams {

  private[made] def this(weights: DenseVector, bias: Double) =
    this(Identifiable.randomUID("linearRegressionModel"), weights, bias)

  override def copy(extra: ParamMap): LinearRegressionModel = ???

  override def transform(dataset: Dataset[_]): DataFrame = {
    val transformUdf = dataset.sqlContext.udf.register(uid + "_transform",
      (x : Vector) => {
        sum(x.asBreeze *:* weights.asBreeze) + w0
      })

    dataset.withColumn($(outputCol), transformUdf(dataset($(inputCol))))
  }

  override def transformSchema(schema: StructType): StructType = validateAndTransformSchema(schema)
}



